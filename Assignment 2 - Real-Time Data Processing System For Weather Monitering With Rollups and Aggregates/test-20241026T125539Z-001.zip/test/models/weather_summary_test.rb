require "test_helper"

class WeatherSummaryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

require "test_helper"

class DailyWeatherSummaryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

require "test_helper"

class WeatherDatumTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

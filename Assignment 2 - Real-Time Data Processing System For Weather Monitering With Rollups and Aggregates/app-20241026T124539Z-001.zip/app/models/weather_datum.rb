class WeatherDatum < ApplicationRecord
end

class DailyWeatherSummary < ApplicationRecord
end

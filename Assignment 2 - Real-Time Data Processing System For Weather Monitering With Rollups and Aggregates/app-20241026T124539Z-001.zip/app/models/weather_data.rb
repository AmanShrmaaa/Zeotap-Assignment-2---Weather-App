class WeatherData < ApplicationRecord
end